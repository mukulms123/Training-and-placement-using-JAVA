package proj;

import java.util.Scanner;

public class InterR {
	Scanner sc=new Scanner(System.in);
	
	InterR(){
		String a,ap;
		Log_r l1= new Log_r();
		System.out.println("\nEnter Recruiter id and password:");
		a=sc.nextLine();
		ap=sc.nextLine();
		int c= l1.match(a, ap);
		if(c==1)
		{
			System.out.println("\nWelcome Recruiter.");
			Rmenu();
		}
		if(c==0)
		{
			System.out.println("\nWrong username or password");
			new Inter();
		}
		
		}
	
	void Rmenu() {
		System.out.println("\nMENU:");
		System.out.println("\nEnter What would you like to do");
		System.out.println("\na=Details of jobs\tb=Get details of applicants \t s=search \t x= Exit\t y=Back to main menu");
		String t= sc.nextLine();
		if(t.compareTo("s")==0) {
			Log_u.search();
			Rmenu();
		}
		if(t.compareTo("a")==0) {
			Jobs.getDetails();
			Rmenu();
		}
		if(t.compareTo("b")==0) {
			Jobs.display();
			Rmenu();
		}
		if(t.compareTo("x")==0) {
			System.out.println("\nExit");
			System.exit(0);
		}
		if(t.compareTo("y")==0) {
			System.out.println("\nBack to main menu:");
			new Inter();
		}
		else {
			System.out.println("\nWrong entry!");
			Rmenu();
		}
	}
}
