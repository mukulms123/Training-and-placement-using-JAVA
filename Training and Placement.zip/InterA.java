package proj;

import java.util.Scanner;

public class InterA {
	Scanner sc=new Scanner(System.in);
	InterA(){
			String a,ap;
			
			Log_a l1= new Log_a();
			System.out.println("\nEnter Admin id and password:");
			a=sc.nextLine();
			ap=sc.nextLine();
			int c= l1.match(a, ap);
			if(c==1)
			{
				System.out.println("\nWelcome admin.");
				Amenu();
			}
			if(c==0)
			{
				System.out.println("\nWrong username or password");
				new Inter();
			}
		}
	
	void Amenu() {
		System.out.println("\nMENU:");
		System.out.println("\nEnter What would you like to do");
		System.out.println("\na= Add Job,\tb=Details of jobs\tc=Get details of applicants\tx= Exit\ty=back to main menu");
		String t= sc.nextLine();
		if(t.compareTo("a")==0) {
			Jobs.addJob();
			Amenu();
		}
		if(t.compareTo("b")==0) {
			Jobs.getDetails();
			Amenu();
		}
		if(t.compareTo("c")==0) {
			Jobs.display();
			Amenu();
		}
		if(t.compareTo("x")==0) {
			System.out.println("\nExit");
			System.exit(0);
		}
		if(t.compareTo("y")==0) {
			System.out.println("\nBack to main menu:");
			new Inter();
		}
		else {
			System.out.println("\nWrong entry!");
			Amenu();
		}
	}
	
	
	
}
