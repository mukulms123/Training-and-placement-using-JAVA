package proj;

import java.util.Scanner;

public class Jobs {
	static Scanner sc= new Scanner(System.in);
	public static String jid[]= new String[100];
	public static int jidl=0;
	public static String jname[]= new String[100];
	public static int jnl=0;
	public static String jdetail[]= new String[100];
	public static int jdl=0;
	public static String j_user[]= new String[100];
	public static int j_ul=0;
	public static String j_id[]= new String[100];
	public static int j_il=0;
	
	
	static void addJob()
	{
		System.out.println("\nEnter job details:");
		System.out.println("Enter job id:");
		jid[jidl]= sc.nextLine();
		jidl++;
		System.out.println("Enter Company name:");
		jname[jnl]= sc.nextLine();
		jnl++;
		System.out.println("Enter details of job:");
		jdetail[jdl]= sc.nextLine();
		jdl++;
	}
	
	
	static void getDetails()
	{
		int i;
		System.out.println("\nJob_id\t| Job_name\t| Job_details |");
		if(jidl==0)
		{
			System.out.println("No job available 'yet'.");
			return;
		}
		for(i=0;i<jidl;i++)
		{
			System.out.println(jid[i]+"\t"+jname[i]+"\t"+jdetail[i]);
		}
	}
	static void apply()
	{
		System.out.println("\nEnter details to aplly for job");
		System.out.println("\nEnter username:");
		j_user[j_ul]=sc.nextLine();
		j_ul++;
		System.out.println("\nEnter Job id:");
		j_id[j_il]=sc.nextLine();
		j_il++;
	}
	static void display()
	{int i;
		System.out.println("\nDetails of applicants.");
		System.out.println("\nUser_id\tJob_details");
		for(i=0;i<j_il;i++)
		{
			System.out.println(j_user[i]+"\t"+j_id[i]);
		}
	}
	
}
