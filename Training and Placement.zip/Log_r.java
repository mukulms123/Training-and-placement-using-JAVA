package proj;

public class Log_r {
	int i,b1,an = 4;
	String r[]= {"R1","R2","R3","R4","R5"};
	String rp[]= {"Ab","Bc","Cd","De","Ef"};
	
	int match(String b,String bp)
	{	for(i=0;i<=an;i++) {
			if(b.compareTo(r[i])==0 && bp.compareTo(rp[i])==0)
			{
				b1=1;
				break;
			}
			else 
			{
				b1=0;
			}
		}
		if(b1==1)
		{
			return 1;
		}
		else {
			return 0;
		}
		
	}
}
