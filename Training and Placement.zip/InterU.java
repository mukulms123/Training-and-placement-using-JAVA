package proj;

import java.util.Scanner;
	
	public class InterU {
		Scanner sc=new Scanner(System.in);
		InterU(){
		String a,ap;
		
		Log_u l1= new Log_u();
		System.out.println("\nEnter User id and password:");
		a=sc.nextLine();
		ap=sc.nextLine();
		int c= l1.match(a, ap);
		if(c==1)
		{
			System.out.println("\nWelcome User.");
			Umenu();
		}
		if(c==0)
		{
			System.out.println("\nWrong username or password");
			new Inter();
		}
		
		}
		void Umenu() {
			System.out.println("\nMENU:");
			System.out.println("\nEnter What would you like to do");
			System.out.println("\na=Details of jobs\tb=Apply for job \t x= Exit \t y=back to main menu");
			String t= sc.nextLine();
			if(t.compareTo("b")==0) {
				Jobs.apply();
				Umenu();
			}
			if(t.compareTo("a")==0) {
				Jobs.getDetails();
				Umenu();
			}
			if(t.compareTo("x")==0) {
				System.out.println("\nExit");
				System.exit(0);
			}
			if(t.compareTo("y")==0) {
				System.out.println("\nBack to main menu:");
				new Inter();
			}
			else {
				System.out.println("\nWrong entry!");
				Umenu();
			}
		}
		
}
