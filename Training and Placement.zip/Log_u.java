package proj;
import java.util.*;
public class Log_u {
	static Scanner sc= new Scanner(System.in);
	static int i,b1,an = 4;
	static String u[]= {"U1","U2","U3","U4","U5"};
	static String up[]= {"Ab","Bc","Cd","De","Ef"};
	static String uname[]= {"Deepak","Mukul","Rishab","Niharika","Nischal"};
	static String ugrad[]= {"B.tech,M.tech,Bsc","B.tech","B.tech","Management","B.tech"};
	
	int match(String b,String bp)
	{	for(i=0;i<=an;i++) {
			if(b.compareTo(u[i])==0 && bp.compareTo(up[i])==0)
			{
				b1=1;
				break;
			}
			else 
			{
				b1=0;
			}
		}
		if(b1==1)
		{
			return 1;
		}
		else {
			return 0;
		}
		
	}
	
	static void search()
	{	int l=0;
		System.out.println("\nEnter User_id:");
		String u1=sc.nextLine();
		for(i=0;i<=an;i++)
		{
			if(u1.compareTo(u[i])==0)
			{
				l=i;
				break;
			}
			else {
				l=6;
			}
		}
		if(l==6)
		{
			System.out.println("\nCan't find the user.");
		}
		else {
			System.out.println("\nU_id |\t U_name |\t Gradaduation");
			System.out.println(u[l]+"\t "+uname[l] +"\t "+ugrad[l]  );
		}
	}
	
	
	
	
}
