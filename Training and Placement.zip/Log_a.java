package proj;

public class Log_a {
	int i,b1,an = 4;
	String a[]= {"Abc","Bcd","Cde","Def","Efg"};
	String ap[]= {"Ab","Bc","Cd","De","Ef"};
	
	int match(String b,String bp)
	{	for(i=0;i<=an;i++) {
			if(b.compareTo(a[i])==0 && bp.compareTo(ap[i])==0)
			{
				b1=1;
				break;
			}
			else 
			{
				b1=0;
			}
		}
		if(b1==1)
		{
			return 1;
		}
		else {
			return 0;
		}
		
	}
}
